/** @type {import('next').NextConfig} */
// What: Explicitly set Turbopack root to the frontend directory.
// Why: Prevents Next.js from inferring the workspace root as the repository root when multiple
//      lockfiles exist (root and ./frontend), eliminating noisy warnings during build.
const nextConfig = {
  turbopack: {
    // __dirname is not available in ESM; process.cwd() resolves to the current project dir
    // when running npm -C frontend, which is exactly what we want.
    root: process.cwd(),
  },
};

export default nextConfig;
